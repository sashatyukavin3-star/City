# CityForge
Свободный изометрический city builder prototype.

## Build
GitHub Actions → Build CityForge Android → Artifact `cityforge-release-apk`.

Godot 4.4.1, Android SDK 35, JDK 17.
