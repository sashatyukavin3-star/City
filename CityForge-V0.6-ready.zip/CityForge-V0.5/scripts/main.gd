extends Node3D

# CityForge 0.5 — free-form city builder prototype.
# Roads are true 3D curves: straight, diagonal, curved and circular.

const ROAD_WIDTH: float = 4.6
const ROAD_Y: float = 0.08
const SAMPLE_STEP: float = 2.2
const MAX_DRAW_DISTANCE: float = 260.0
const GRID_SIZE: float = 8.0

var roads: Array[Dictionary] = []
var current_points: Array[Vector3] = []
var drawing: bool = false
var road_mode: bool = true
var zone_mode: bool = false
var camera: Camera3D
var road_root: Node3D
var traffic_root: Node3D
var building_root: Node3D
var zone_root: Node3D
var preview: MeshInstance3D
var status_label: Label
var stats_label: Label
var population: int = 12840
var money: int = 245680

func _ready() -> void:
    _build_environment()
    _build_world()
    _build_ui()
    _spawn_demo_city()

func _build_environment() -> void:
    var env: WorldEnvironment = WorldEnvironment.new()
    var e: Environment = Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#0d1520")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#b7c9dc")
    e.ambient_light_energy = 0.8
    env.environment = e
    add_child(env)

    var sun: DirectionalLight3D = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55.0, -35.0, 0.0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

    camera = Camera3D.new()
    camera.position = Vector3(0.0, 52.0, 42.0)
    camera.rotation_degrees = Vector3(-52.0, 0.0, 0.0)
    camera.current = true
    camera.fov = 48.0
    add_child(camera)

func _build_world() -> void:
    var world_root: Node3D = Node3D.new()
    world_root.name = "World"
    add_child(world_root)

    road_root = Node3D.new()
    road_root.name = "RoadNetwork"
    world_root.add_child(road_root)

    traffic_root = Node3D.new()
    traffic_root.name = "Traffic"
    world_root.add_child(traffic_root)

    building_root = Node3D.new()
    building_root.name = "Buildings"
    world_root.add_child(building_root)

    zone_root = Node3D.new()
    zone_root.name = "Zones"
    world_root.add_child(zone_root)

    var ground: MeshInstance3D = MeshInstance3D.new()
    var plane: PlaneMesh = PlaneMesh.new()
    plane.size = Vector2(240.0, 240.0)
    ground.mesh = plane
    ground.position.y = -0.12
    ground.material_override = _mat(Color("#263a30"))
    world_root.add_child(ground)

    _create_water(world_root)
    _create_grid(world_root)

func _create_water(parent: Node3D) -> void:
    var water: MeshInstance3D = MeshInstance3D.new()
    var mesh: PlaneMesh = PlaneMesh.new()
    mesh.size = Vector2(70.0, 150.0)
    water.mesh = mesh
    water.position = Vector3(82.0, -0.04, -5.0)
    water.material_override = _mat(Color("#20546a"))
    parent.add_child(water)

func _create_grid(parent: Node3D) -> void:
    var grid: ImmediateMesh = ImmediateMesh.new()
    grid.surface_begin(Mesh.PRIMITIVE_LINES)
    var extent: float = 110.0
    var step: float = 8.0
    var x: float = -extent
    while x <= extent:
        grid.surface_add_vertex(Vector3(x, 0.005, -extent))
        grid.surface_add_vertex(Vector3(x, 0.005, extent))
        x += step
    var z: float = -extent
    while z <= extent:
        grid.surface_add_vertex(Vector3(-extent, 0.005, z))
        grid.surface_add_vertex(Vector3(extent, 0.005, z))
        z += step
    grid.surface_end()
    var lines: MeshInstance3D = MeshInstance3D.new()
    lines.mesh = grid
    lines.material_override = _mat(Color(0.34, 0.48, 0.40, 0.14))
    parent.add_child(lines)

func _spawn_demo_city() -> void:
    _create_road([Vector3(-76.0, ROAD_Y, 34.0), Vector3(-42.0, ROAD_Y, 27.0), Vector3(-10.0, ROAD_Y, 10.0), Vector3(22.0, ROAD_Y, -4.0), Vector3(60.0, ROAD_Y, -28.0)])
    _create_road([Vector3(-60.0, ROAD_Y, -48.0), Vector3(-32.0, ROAD_Y, -23.0), Vector3(0.0, ROAD_Y, 1.0), Vector3(30.0, ROAD_Y, 26.0), Vector3(67.0, ROAD_Y, 56.0)])
    var ring: Array[Vector3] = []
    for i: int in range(33):
        var angle: float = TAU * float(i) / 32.0
        ring.append(Vector3(cos(angle) * 25.0, ROAD_Y, sin(angle) * 25.0))
    _create_road(ring, true)

    var lots: Array[Dictionary] = [
        {"p": Vector3(-56.0, 0.0, 8.0), "s": Vector3(8.0, 10.0, 8.0), "c": Color("#aeb8c2")},
        {"p": Vector3(-42.0, 0.0, -13.0), "s": Vector3(9.0, 14.0, 8.0), "c": Color("#c7a77b")},
        {"p": Vector3(-24.0, 0.0, 19.0), "s": Vector3(10.0, 8.0, 10.0), "c": Color("#8eabbc")},
        {"p": Vector3(4.0, 0.0, -18.0), "s": Vector3(11.0, 17.0, 10.0), "c": Color("#9a7d70")},
        {"p": Vector3(39.0, 0.0, 9.0), "s": Vector3(9.0, 12.0, 8.0), "c": Color("#7c9db0")},
        {"p": Vector3(49.0, 0.0, -17.0), "s": Vector3(12.0, 9.0, 9.0), "c": Color("#b58b65")},
        {"p": Vector3(5.0, 0.0, 45.0), "s": Vector3(13.0, 7.0, 10.0), "c": Color("#7e9a78")},
        {"p": Vector3(-61.0, 0.0, -56.0), "s": Vector3(14.0, 19.0, 12.0), "c": Color("#7f91a8")}
    ]
    for lot: Dictionary in lots:
        _spawn_building(lot["p"] as Vector3, lot["s"] as Vector3, lot["c"] as Color)

    for p: Vector3 in [Vector3(-4.0, 0.0, 42.0), Vector3(31.0, 0.0, 38.0), Vector3(-72.0, 0.0, -18.0), Vector3(58.0, 0.0, 30.0)]:
        _spawn_tree_cluster(p)

func _spawn_building(pos: Vector3, size: Vector3, color: Color) -> void:
    var root: Node3D = Node3D.new()
    root.position = pos
    building_root.add_child(root)

    var body: MeshInstance3D = MeshInstance3D.new()
    var box: BoxMesh = BoxMesh.new()
    box.size = size
    body.mesh = box
    body.position.y = size.y * 0.5
    body.material_override = _mat(color)
    root.add_child(body)

    var roof: MeshInstance3D = MeshInstance3D.new()
    var roof_mesh: BoxMesh = BoxMesh.new()
    roof_mesh.size = Vector3(size.x * 0.92, 0.55, size.z * 0.92)
    roof.mesh = roof_mesh
    roof.position.y = size.y + 0.28
    roof.material_override = _mat(Color("#354452"))
    root.add_child(roof)

    var floor_count: int = maxi(1, int(size.y / 3.0))
    for i: int in range(floor_count):
        var band: MeshInstance3D = MeshInstance3D.new()
        var bm: BoxMesh = BoxMesh.new()
        bm.size = Vector3(size.x * 1.01, 0.10, size.z * 0.92)
        band.mesh = bm
        band.position.y = 1.7 + float(i) * 3.0
        band.material_override = _mat(Color("#d7e1e5"))
        root.add_child(band)

func _spawn_tree_cluster(center: Vector3) -> void:
    for i: int in range(8):
        var angle: float = TAU * float(i) / 8.0
        var radius: float = 5.0 + float(i % 3) * 2.0
        var p: Vector3 = center + Vector3(cos(angle) * radius, 0.0, sin(angle) * radius)

        var trunk: MeshInstance3D = MeshInstance3D.new()
        var cyl: CylinderMesh = CylinderMesh.new()
        cyl.height = 2.2
        cyl.top_radius = 0.18
        cyl.bottom_radius = 0.28
        trunk.mesh = cyl
        trunk.position = p + Vector3(0.0, 1.1, 0.0)
        trunk.material_override = _mat(Color("#5a4030"))
        building_root.add_child(trunk)

        var crown: MeshInstance3D = MeshInstance3D.new()
        var sph: SphereMesh = SphereMesh.new()
        sph.radius = 1.7
        sph.height = 3.1
        crown.mesh = sph
        crown.position = p + Vector3(0.0, 3.1, 0.0)
        crown.material_override = _mat(Color("#39714a"))
        building_root.add_child(crown)

func _create_road(points: Array[Vector3], closed: bool = false) -> void:
    if points.size() < 2:
        return
    var curve: Curve3D = Curve3D.new()
    curve.bake_interval = 0.6
    curve.closed = closed
    for p: Vector3 in points:
        curve.add_point(p)

    var road_mesh_instance: MeshInstance3D = MeshInstance3D.new()
    road_mesh_instance.name = "Road"
    road_mesh_instance.mesh = _road_mesh(curve)
    road_mesh_instance.material_override = _mat(Color("#252b31"))
    road_root.add_child(road_mesh_instance)

    var lane: MeshInstance3D = MeshInstance3D.new()
    lane.mesh = _line_mesh(curve)
    lane.material_override = _mat(Color("#e6df9d"))
    road_root.add_child(lane)

    var length: float = curve.get_baked_length()
    roads.append({"curve": curve, "length": length, "closed": closed})
    _spawn_car(roads[roads.size() - 1])

func _road_mesh(curve: Curve3D) -> ArrayMesh:
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var length: float = curve.get_baked_length()
    var count: int = maxi(2, int(length / SAMPLE_STEP))
    for i: int in range(count):
        var d0: float = length * float(i) / float(count)
        var d1: float = length * float(i + 1) / float(count)
        var p0: Vector3 = curve.sample_baked(d0)
        var p1: Vector3 = curve.sample_baked(d1)
        var dir: Vector3 = (p1 - p0).normalized()
        var side: Vector3 = Vector3(-dir.z, 0.0, dir.x)
        var a: Vector3 = p0 + side * ROAD_WIDTH * 0.5
        var b: Vector3 = p0 - side * ROAD_WIDTH * 0.5
        var c: Vector3 = p1 + side * ROAD_WIDTH * 0.5
        var d: Vector3 = p1 - side * ROAD_WIDTH * 0.5
        st.add_vertex(a); st.add_vertex(b); st.add_vertex(c)
        st.add_vertex(b); st.add_vertex(d); st.add_vertex(c)
    return st.commit()

func _line_mesh(curve: Curve3D) -> ArrayMesh:
    var st: SurfaceTool = SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var length: float = curve.get_baked_length()
    var count: int = maxi(2, int(length / SAMPLE_STEP))
    for i: int in range(count):
        var d0: float = length * float(i) / float(count)
        var d1: float = length * float(i + 1) / float(count)
        var p0: Vector3 = curve.sample_baked(d0) + Vector3(0.0, 0.035, 0.0)
        var p1: Vector3 = curve.sample_baked(d1) + Vector3(0.035, 0.035, 0.0)
        var dir: Vector3 = (p1 - p0).normalized()
        var side: Vector3 = Vector3(-dir.z, 0.0, dir.x)
        var w: float = 0.075
        st.add_vertex(p0 + side * w); st.add_vertex(p0 - side * w); st.add_vertex(p1 + side * w)
        st.add_vertex(p0 - side * w); st.add_vertex(p1 - side * w); st.add_vertex(p1 + side * w)
    return st.commit()

func _spawn_car(road: Dictionary) -> void:
    var car: MeshInstance3D = MeshInstance3D.new()
    var box: BoxMesh = BoxMesh.new()
    box.size = Vector3(1.45, 0.7, 2.6)
    car.mesh = box
    var palette: Array[Color] = [Color("#e85c4a"), Color("#e4b63e"), Color("#5a9fe6"), Color("#eeeeee")]
    var car_color: Color = palette[randi() % palette.size()]
    car.material_override = _mat(car_color)
    car.set_meta("road", road)
    car.set_meta("distance", randf_range(0.0, float(road["length"])))
    car.set_meta("speed", randf_range(6.0, 11.0))
    traffic_root.add_child(car)

func _process(delta: float) -> void:
    _update_cars(delta)
    if drawing:
        _update_preview()

func _update_cars(delta: float) -> void:
    for node: Node in traffic_root.get_children():
        var car: MeshInstance3D = node as MeshInstance3D
        if car == null:
            continue
        var road_variant: Variant = car.get_meta("road")
        if not (road_variant is Dictionary):
            continue
        var road: Dictionary = road_variant as Dictionary
        var curve_variant: Variant = road.get("curve")
        if not (curve_variant is Curve3D):
            continue
        var curve: Curve3D = curve_variant as Curve3D
        var old_distance_variant: Variant = car.get_meta("distance")
        var speed_variant: Variant = car.get_meta("speed")
        var distance: float = float(old_distance_variant) + float(speed_variant) * delta
        var length: float = float(road["length"])
        if length <= 0.1:
            continue
        if distance >= length:
            distance = fmod(distance, length)
        var p: Vector3 = curve.sample_baked(distance)
        var ahead_distance: float = min(distance + 0.9, length)
        var ahead: Vector3 = curve.sample_baked(ahead_distance)
        car.position = p + Vector3(0.0, 0.45, 0.0)
        car.look_at(Vector3(ahead.x, car.position.y, ahead.z), Vector3.UP)
        car.set_meta("distance", distance)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        var touch: InputEventScreenTouch = event as InputEventScreenTouch
        if touch.pressed:
            _start_action(touch.position)
        else:
            _finish_action()
    elif event is InputEventScreenDrag:
        var drag: InputEventScreenDrag = event as InputEventScreenDrag
        if drawing:
            _add_draw_point(drag.position)
    elif event is InputEventMouseButton:
        var mouse: InputEventMouseButton = event as InputEventMouseButton
        if mouse.button_index == MOUSE_BUTTON_LEFT:
            if mouse.pressed:
                _start_action(mouse.position)
            else:
                _finish_action()
    elif event is InputEventMouseMotion:
        var motion: InputEventMouseMotion = event as InputEventMouseMotion
        if drawing:
            _add_draw_point(motion.position)
    elif event is InputEventKey:
        var key: InputEventKey = event as InputEventKey
        if key.pressed and key.keycode == KEY_ESCAPE:
            drawing = false
            current_points.clear()
            _clear_preview()

func _start_action(screen: Vector2) -> void:
    if not road_mode and not zone_mode:
        return
    drawing = true
    current_points.clear()
    var p: Vector3 = _screen_to_ground(screen)
    if road_mode:
        current_points.append(Vector3(p.x, ROAD_Y, p.z))
    else:
        _paint_zone(p)

func _add_draw_point(screen: Vector2) -> void:
    var p: Vector3 = _screen_to_ground(screen)
    if zone_mode:
        _paint_zone(p)
        return
    if current_points.is_empty() or current_points[current_points.size() - 1].distance_to(p) > 1.0:
        current_points.append(Vector3(p.x, ROAD_Y, p.z))

func _finish_action() -> void:
    if not drawing:
        return
    drawing = false
    if road_mode and current_points.size() >= 2:
        _create_road(current_points.duplicate())
        status_label.text = "ДОРОГА СОЗДАНА  •  СВОБОДНАЯ ГЕОМЕТРИЯ"
        money = maxi(0, money - current_points.size() * 8)
        _refresh_stats()
    current_points.clear()
    _clear_preview()

func _paint_zone(p: Vector3) -> void:
    var snapped: Vector3 = Vector3(round(p.x / GRID_SIZE) * GRID_SIZE, 0.02, round(p.z / GRID_SIZE) * GRID_SIZE)
    var key: String = "%d:%d" % [int(snapped.x), int(snapped.z)]
    if zone_root.has_node(NodePath(key)):
        return
    var tile: MeshInstance3D = MeshInstance3D.new()
    tile.name = key
    var plane: BoxMesh = BoxMesh.new()
    plane.size = Vector3(7.5, 0.08, 7.5)
    tile.mesh = plane
    tile.position = snapped
    tile.material_override = _mat(Color(0.22, 0.55, 0.35, 0.65))
    zone_root.add_child(tile)
    population += 12
    money = maxi(0, money - 40)
    _refresh_stats()

func _screen_to_ground(screen: Vector2) -> Vector3:
    var from: Vector3 = camera.project_ray_origin(screen)
    var dir: Vector3 = camera.project_ray_normal(screen)
    if absf(dir.y) < 0.001:
        return Vector3.ZERO
    var t: float = -from.y / dir.y
    if t < 0.0 or t > MAX_DRAW_DISTANCE:
        return Vector3.ZERO
    return from + dir * t

func _update_preview() -> void:
    if current_points.size() < 2:
        return
    var mesh: ImmediateMesh = ImmediateMesh.new()
    mesh.surface_begin(Mesh.PRIMITIVE_LINES)
    for i: int in range(current_points.size() - 1):
        mesh.surface_add_vertex(current_points[i] + Vector3(0.0, 0.12, 0.0))
        mesh.surface_add_vertex(current_points[i + 1] + Vector3(0.0, 0.12, 0.0))
    mesh.surface_end()
    if preview == null:
        preview = MeshInstance3D.new()
        add_child(preview)
        preview.material_override = _mat(Color("#f4d35e"))
    preview.mesh = mesh

func _clear_preview() -> void:
    if preview != null:
        preview.mesh = null

func _build_ui() -> void:
    var layer: CanvasLayer = CanvasLayer.new()
    add_child(layer)

    var top: Panel = Panel.new()
    top.position = Vector2(18.0, 18.0)
    top.size = Vector2(470.0, 112.0)
    top.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.055, 0.075, 0.94), 18.0))
    layer.add_child(top)

    var title: Label = Label.new()
    title.position = Vector2(22.0, 14.0)
    title.text = "CITYFORGE"
    title.add_theme_font_size_override("font_size", 30)
    top.add_child(title)

    stats_label = Label.new()
    stats_label.position = Vector2(22.0, 58.0)
    stats_label.add_theme_font_size_override("font_size", 16)
    top.add_child(stats_label)
    _refresh_stats()

    var hint: Label = Label.new()
    hint.position = Vector2(22.0, 142.0)
    hint.text = "Проведи пальцем: строй дорогу или закрашивай зоны"
    hint.add_theme_font_size_override("font_size", 15)
    layer.add_child(hint)

    var road_button: Button = _make_button("🛣  ДОРОГИ", Vector2(22.0, 640.0), Vector2(190.0, 58.0))
    road_button.pressed.connect(_select_road)
    layer.add_child(road_button)

    var zone_button: Button = _make_button("▦  ЗОНЫ", Vector2(222.0, 640.0), Vector2(160.0, 58.0))
    zone_button.pressed.connect(_select_zone)
    layer.add_child(zone_button)

    var clear_button: Button = _make_button("СБРОС", Vector2(392.0, 640.0), Vector2(125.0, 58.0))
    clear_button.pressed.connect(_clear_last_road)
    layer.add_child(clear_button)

    status_label = Label.new()
    status_label.position = Vector2(930.0, 28.0)
    status_label.text = "V0.5  •  FREE ROAD"
    status_label.add_theme_font_size_override("font_size", 15)
    layer.add_child(status_label)

func _make_button(text: String, pos: Vector2, size: Vector2) -> Button:
    var button: Button = Button.new()
    button.text = text
    button.position = pos
    button.size = size
    button.add_theme_font_size_override("font_size", 17)
    return button

func _select_road() -> void:
    road_mode = true
    zone_mode = false
    status_label.text = "РЕЖИМ: ДОРОГИ"

func _select_zone() -> void:
    road_mode = false
    zone_mode = true
    status_label.text = "РЕЖИМ: ЗОНЫ"

func _clear_last_road() -> void:
    if roads.is_empty():
        return
    var road: Dictionary = roads.pop_back()
    if road_root.get_child_count() >= 2:
        var n: int = road_root.get_child_count()
        road_root.get_child(n - 1).queue_free()
        road_root.get_child(n - 2).queue_free()
    if traffic_root.get_child_count() > 0:
        traffic_root.get_child(traffic_root.get_child_count() - 1).queue_free()
    status_label.text = "ПОСЛЕДНЯЯ ДОРОГА УДАЛЕНА"
    money += 120
    _refresh_stats()

func _refresh_stats() -> void:
    if stats_label != null:
        stats_label.text = "НАСЕЛЕНИЕ  %s     КАЗНА  €%s" % [String.num_int64(population), String.num_int64(money)]

func _panel_style(color: Color, radius: float) -> StyleBoxFlat:
    var style: StyleBoxFlat = StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = int(radius)
    style.corner_radius_top_right = int(radius)
    style.corner_radius_bottom_left = int(radius)
    style.corner_radius_bottom_right = int(radius)
    return style

func _mat(color: Color, roughness: float = 0.9) -> StandardMaterial3D:
    var material: StandardMaterial3D = StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    return material
