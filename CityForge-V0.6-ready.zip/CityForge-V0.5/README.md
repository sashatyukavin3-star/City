# CityForge V0.6

Android city-builder prototype with free-form 3D roads, diagonal roads, curved roads, circular roads, zones and traffic following the actual Curve3D path.

## CI
The repository workflow should extract this ZIP, install Godot 4.4.1 + Android SDK/JDK and export `build/CityForge.apk`.

## Android target
SDK 34 / JDK 17. Gradle mode is disabled for the current lightweight export, so no release keystore is required by the preset.

## Controls
- Drag: draw a road
- Zones: paint zones
- Roads: return to road drawing
- Reset: remove last road
