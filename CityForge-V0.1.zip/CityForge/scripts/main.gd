extends Node3D

# CityForge V0.1
# Свободная геометрия: дорога = spline + mesh, а не tile/cell.
# Машины двигаются по реальной кривой дороги.

var roads: Array[Dictionary] = []
var current_points: Array[Vector3] = []
var drawing := false
var road_mode := true
var zone_mode := false

var world_root: Node3D
var road_root: Node3D
var car_root: Node3D
var building_root: Node3D
var camera: Camera3D
var status_label: Label
var population_label: Label

const ROAD_WIDTH := 4.4
const ROAD_Y := 0.08
const SAMPLE_STEP := 2.5
const MAX_DRAW_DISTANCE := 220.0

func _ready() -> void:
    _build_environment()
    _build_world()
    _build_ui()
    _spawn_demo_city()

func _build_environment() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color("#111923")
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color("#b7c9dc")
    e.ambient_light_energy = 0.72
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    e.glow_enabled = false
    env.environment = e
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -35, 0)
    sun.light_energy = 1.15
    sun.shadow_enabled = true
    add_child(sun)

    camera = Camera3D.new()
    camera.position = Vector3(0, 42, 34)
    camera.rotation_degrees = Vector3(-52, 0, 0)
    camera.current = true
    camera.fov = 48
    add_child(camera)

func _build_world() -> void:
    world_root = Node3D.new()
    world_root.name = "World"
    add_child(world_root)

    road_root = Node3D.new()
    road_root.name = "RoadNetwork"
    world_root.add_child(road_root)

    car_root = Node3D.new()
    car_root.name = "Traffic"
    world_root.add_child(car_root)

    building_root = Node3D.new()
    building_root.name = "Buildings"
    world_root.add_child(building_root)

    # Terrain
    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(240, 240)
    plane.subdivide_width = 2
    plane.subdivide_depth = 2
    ground.mesh = plane
    ground.position.y = -0.12
    ground.material_override = _mat(Color("#25352b"))
    world_root.add_child(ground)

    # subtle water
    var water := MeshInstance3D.new()
    var wp := PlaneMesh.new()
    wp.size = Vector2(80, 42)
    water.mesh = wp
    water.position = Vector3(68, -0.02, -52)
    water.material_override = _mat(Color("#1f5366"), 0.88)
    world_root.add_child(water)

func _spawn_demo_city() -> void:
    # Main curved boulevard
    _create_road([Vector3(-75,ROAD_Y,32),Vector3(-38,ROAD_Y,25),Vector3(-8,ROAD_Y,10),Vector3(25,ROAD_Y,-3),Vector3(55,ROAD_Y,-25)])
    # Diagonal road
    _create_road([Vector3(-55,ROAD_Y,-40),Vector3(-30,ROAD_Y,-20),Vector3(-4,ROAD_Y,0),Vector3(28,ROAD_Y,24),Vector3(62,ROAD_Y,50)])
    # Ring road
    var ring: Array[Vector3] = []
    for i in range(25):
        var a := TAU * float(i) / 24.0
        ring.append(Vector3(cos(a)*24.0, ROAD_Y, sin(a)*24.0))
    _create_road(ring, true)

    # Buildings deliberately sit around roads without being cell-bound.
    var lots := [
        [Vector3(-54,0,8), Vector3(7,9,8), Color("#aeb8c2")],
        [Vector3(-42,0,-12), Vector3(8,13,8), Color("#c7a77b")],
        [Vector3(-24,0,18), Vector3(9,7,10), Color("#8eabbc")],
        [Vector3(4,0,-17), Vector3(10,16,10), Color("#9a7d70")],
        [Vector3(38,0,8), Vector3(8,11,8), Color("#7c9db0")],
        [Vector3(47,0,-16), Vector3(11,8,9), Color("#b58b65")],
        [Vector3(5,0,45), Vector3(12,6,10), Color("#7e9a78")],
        [Vector3(-60,0,-55), Vector3(14,18,12), Color("#7f91a8")]
    ]
    for lot in lots:
        _spawn_building(lot[0], lot[1], lot[2])

    # parks/trees
    for p in [Vector3(-4,0,42),Vector3(31,0,38),Vector3(-72,0,-18),Vector3(58,0,30)]:
        _spawn_tree_cluster(p)

func _spawn_building(pos: Vector3, size: Vector3, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    building_root.add_child(root)

    var body := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    body.mesh = box
    body.position.y = size.y/2.0
    body.material_override = _mat(color)
    root.add_child(body)

    var roof := MeshInstance3D.new()
    var roof_mesh := BoxMesh.new()
    roof_mesh.size = Vector3(size.x*0.92, 0.55, size.z*0.92)
    roof.mesh = roof_mesh
    roof.position.y = size.y + 0.28
    roof.material_override = _mat(Color("#354452"))
    root.add_child(roof)

    # facade bands = more visual detail
    for y in range(2, int(max(3.0,size.y)), 3):
        var band := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(size.x*1.01, 0.12, size.z*0.92)
        band.mesh = bm
        band.position.y = y
        band.material_override = _mat(Color("#d7e1e5"), 0.8)
        root.add_child(band)

func _spawn_tree_cluster(center: Vector3) -> void:
    for i in range(8):
        var angle := TAU * float(i)/8.0
        var p := center + Vector3(cos(angle)*randf_range(3,12),0,sin(angle)*randf_range(3,12))
        var trunk := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.height = 2.2
        cyl.top_radius = 0.18
        cyl.bottom_radius = 0.28
        trunk.mesh = cyl
        trunk.position = p + Vector3(0,1.1,0)
        trunk.material_override = _mat(Color("#5a4030"))
        world_root.add_child(trunk)

        var crown := MeshInstance3D.new()
        var sph := SphereMesh.new()
        sph.radius = 1.7
        sph.height = 3.1
        crown.mesh = sph
        crown.position = p + Vector3(0,3.1,0)
        crown.material_override = _mat(Color("#39714a"))
        world_root.add_child(crown)

func _create_road(points: Array[Vector3], closed := false) -> void:
    if points.size() < 2:
        return

    var curve := Curve3D.new()
    curve.bake_interval = 0.6
    curve.closed = closed
    for p in points:
        curve.add_point(p)

    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = "Road"
    mesh_instance.mesh = _road_mesh(curve, closed)
    mesh_instance.material_override = _mat(Color("#252b31"))
    road_root.add_child(mesh_instance)

    # lane markings are thin white geometry sampled along the exact same curve.
    var line := MeshInstance3D.new()
    line.name = "LaneMarking"
    line.mesh = _line_mesh(curve, closed, ROAD_WIDTH*0.5)
    line.material_override = _mat(Color("#e6df9d"))
    road_root.add_child(line)

    roads.append({"curve":curve, "length":curve.get_baked_length(), "closed":closed})
    _spawn_car(roads[-1])

func _road_mesh(curve: Curve3D, closed: bool) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var length := curve.get_baked_length()
    var count := max(2, int(length / SAMPLE_STEP))
    for i in range(count):
        var d0 := length * float(i) / float(count)
        var d1 := length * float(i+1) / float(count)
        var p0 := curve.sample_baked(d0)
        var p1 := curve.sample_baked(d1)
        var dir := (p1-p0).normalized()
        var side := Vector3(-dir.z,0,dir.x)
        var a := p0 + side*ROAD_WIDTH*0.5
        var b := p0 - side*ROAD_WIDTH*0.5
        var c := p1 + side*ROAD_WIDTH*0.5
        var d := p1 - side*ROAD_WIDTH*0.5
        st.set_uv(Vector2(0,0)); st.add_vertex(a)
        st.set_uv(Vector2(1,0)); st.add_vertex(b)
        st.set_uv(Vector2(0,1)); st.add_vertex(c)
        st.set_uv(Vector2(1,0)); st.add_vertex(b)
        st.set_uv(Vector2(1,1)); st.add_vertex(d)
        st.set_uv(Vector2(0,1)); st.add_vertex(c)
    return st.commit()

func _line_mesh(curve: Curve3D, closed: bool, offset: float) -> ArrayMesh:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var length := curve.get_baked_length()
    var count := max(2, int(length / SAMPLE_STEP))
    for i in range(count):
        var d0 := length * float(i) / float(count)
        var d1 := length * float(i+1) / float(count)
        var p0 := curve.sample_baked(d0)
        var p1 := curve.sample_baked(d1)
        var dir := (p1-p0).normalized()
        var side := Vector3(-dir.z,0,dir.x)
        var center0 := p0 + Vector3(0,0.035,0)
        var center1 := p1 + Vector3(0,0.035,0)
        var w := 0.075
        var a := center0 + side*w
        var b := center0 - side*w
        var c := center1 + side*w
        var d := center1 - side*w
        st.add_vertex(a); st.add_vertex(b); st.add_vertex(c)
        st.add_vertex(b); st.add_vertex(d); st.add_vertex(c)
    return st.commit()

func _spawn_car(road: Dictionary) -> void:
    var car := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(1.45,0.7,2.6)
    car.mesh = box
    car.material_override = _mat([Color("#e85c4a"),Color("#e4b63e"),Color("#5a9fe6"),Color("#eeeeee")].pick_random())
    car.set_meta("road", road)
    car.set_meta("distance", randf_range(0, road.length))
    car.set_meta("speed", randf_range(6.0,11.0))
    car_root.add_child(car)

func _process(delta: float) -> void:
    _update_cars(delta)
    if drawing:
        _draw_preview()

func _update_cars(delta: float) -> void:
    for car in car_root.get_children():
        var road: Dictionary = car.get_meta("road")
        var curve: Curve3D = road["curve"]
        var distance: float = car.get_meta("distance") + float(car.get_meta("speed"))*delta
        var length: float = road["length"]
        if distance >= length:
            distance = 0.0 if road["closed"] else length
            if not road["closed"]:
                distance = 0.0
        var p := curve.sample_baked(distance)
        var ahead := curve.sample_baked(min(distance+0.8,length))
        car.position = p + Vector3(0,0.45,0)
        car.look_at(Vector3(ahead.x,car.position.y,ahead.z), Vector3.UP)
        car.set_meta("distance", distance)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            _start_drawing(event.position)
        else:
            _finish_drawing()
    elif event is InputEventScreenDrag and drawing:
        _add_draw_point(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            _start_drawing(event.position)
        else:
            _finish_drawing()
    elif event is InputEventMouseMotion and drawing:
        _add_draw_point(event.position)
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        drawing = false
        current_points.clear()

func _screen_to_ground(screen: Vector2) -> Vector3:
    var from := camera.project_ray_origin(screen)
    var dir := camera.project_ray_normal(screen)
    if abs(dir.y) < 0.001:
        return Vector3.ZERO
    var t := -from.y / dir.y
    if t < 0 or t > MAX_DRAW_DISTANCE:
        return Vector3.ZERO
    return from + dir*t

func _start_drawing(screen: Vector2) -> void:
    if not road_mode:
        return
    drawing = true
    current_points.clear()
    var p := _screen_to_ground(screen)
    current_points.append(Vector3(p.x, ROAD_Y, p.z))

func _add_draw_point(screen: Vector2) -> void:
    var p := _screen_to_ground(screen)
    if current_points.is_empty() or current_points[-1].distance_to(p) > 1.2:
        current_points.append(Vector3(p.x, ROAD_Y, p.z))

func _finish_drawing() -> void:
    if not drawing:
        return
    drawing = false
    if current_points.size() >= 2:
        _create_road(current_points.duplicate(), false)
    current_points.clear()

func _draw_preview() -> void:
    # Lightweight visual preview using a Line3D-like immediate mesh.
    # It disappears when drawing finishes.
    pass

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)

    var top := ColorRect.new()
    top.position = Vector2(18,18)
    top.size = Vector2(390,96)
    top.color = Color(0.03,0.05,0.07,0.88)
    layer.add_child(top)

    var title := Label.new()
    title.position = Vector2(38,30)
    title.text = "CITYFORGE"
    title.add_theme_font_size_override("font_size",28)
    layer.add_child(title)

    population_label = Label.new()
    population_label.position = Vector2(38,66)
    population_label.text = "Население  12 840   •   € 245 680"
    population_label.add_theme_font_size_override("font_size",16)
    layer.add_child(population_label)

    var hint := Label.new()
    hint.position = Vector2(22,132)
    hint.text = "Дорога: проведите пальцем по карте"
    hint.add_theme_font_size_override("font_size",16)
    layer.add_child(hint)

    var road_button := Button.new()
    road_button.text = "🛣  ДОРОГА"
    road_button.position = Vector2(22,650)
    road_button.size = Vector2(190,54)
    road_button.add_theme_font_size_override("font_size",18)
    road_button.pressed.connect(func(): road_mode=true; zone_mode=false)
    layer.add_child(road_button)

    var zone_button := Button.new()
    zone_button.text = "▦  ЗОНА"
    zone_button.position = Vector2(222,650)
    zone_button.size = Vector2(150,54)
    zone_button.add_theme_font_size_override("font_size",18)
    zone_button.pressed.connect(func(): zone_mode=true; road_mode=false)
    layer.add_child(zone_button)

    status_label = Label.new()
    status_label.position = Vector2(1030,28)
    status_label.text = "V0.1  •  FREE ROAD"
    status_label.add_theme_font_size_override("font_size",15)
    layer.add_child(status_label)

func _mat(color: Color, roughness := 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m
