# CityForge V0.1

Экспериментальный Android-friendly прототип свободного city builder.

## Что уже заложено
- изометрическая 3D-камера;
- свободное рисование дорог произвольной формы;
- дороги строятся как реальная геометрия, а не как набор клеток;
- машины следуют по кривой дороги;
- круговые/диагональные/плавные дороги возможны;
- процедурные здания и деревья;
- базовое зонирование кистью;
- тёмный современный HUD;
- управление мышью и touch;
- вся сцена создаётся кодом, поэтому прототип не зависит от внешних ассетов.

## Запуск
Godot 4.x → Import → выбрать `project.godot` → Run.

Для Android:
Project → Export → Android.

## Следующий этап
1. полноценные перекрёстки и lane graph;
2. светофоры;
3. нормальная система участков;
4. строительство зданий по форме участка;
5. экономика и население;
6. сохранения;
7. LOD/батчинг для больших городов;
8. импорт качественных 3D-ассетов.


## Android CI
The repository contains an Android export preset. CI installs Godot export templates and Android SDK components, then runs `godot --headless --export-release "Android" build/CityForge.apk`.

## CI
The GitHub Actions workflow installs Godot 4.4.1 and the matching Android export templates before exporting the release APK.
